global.shatter_order = [4, 1, 2, 0, 3, 6, 7, 16, 5, 8, 9, 13, 14, 18, 11, 12, 15, 17];
CustomShatterReader()